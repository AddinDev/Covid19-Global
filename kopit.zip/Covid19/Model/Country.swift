// This file was generated from JSON Schema using quicktype, do not modify it directly.
// To parse the JSON, add this file to your project and do:
//
//   let purpleData = try? newJSONDecoder().decode(PurpleData.self, from: jsonData)

import Foundation

// MARK: - PurpleData
struct PurpleData: Codable {
    let global: Global
    let countries: [Country]

    enum CodingKeys: String, CodingKey {
        case global = "Global"
        case countries = "Countries"
    }
    
    
}

// MARK: - Country
struct Country: Codable, Identifiable {
    var id = UUID()
    let country, countryCode, slug: String
    let newConfirmed, totalConfirmed, newDeaths, totalDeaths: Int
    let newRecovered, totalRecovered: Int
//    let date: String
//    let premium: Premium

    enum CodingKeys: String, CodingKey {
        case country = "Country"
        case countryCode = "CountryCode"
        case slug = "Slug"
        case newConfirmed = "NewConfirmed"
        case totalConfirmed = "TotalConfirmed"
        case newDeaths = "NewDeaths"
        case totalDeaths = "TotalDeaths"
        case newRecovered = "NewRecovered"
        case totalRecovered = "TotalRecovered"
//        case date = "Date"
//        case premium = "Premium"
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        
        country = try container.decode(String.self, forKey: .country)
        countryCode = try container.decode(String.self, forKey: .countryCode)
        slug = try container.decode(String.self, forKey: .slug)
        

        newConfirmed = try container.decode(Int.self, forKey: .newConfirmed)
        totalConfirmed = try container.decode(Int.self, forKey: .totalConfirmed)
        newDeaths = try container.decode(Int.self, forKey: .newDeaths)
        totalDeaths = try container.decode(Int.self, forKey: .totalDeaths)
        newRecovered = try container.decode(Int.self, forKey: .newRecovered)
        totalRecovered = try container.decode(Int.self, forKey: .totalRecovered)
        
        
    }
    
}

// MARK: - Premium
struct Premium: Codable {
}

// MARK: - Global
struct Global: Codable {
    let newConfirmed, totalConfirmed, newDeaths, totalDeaths: Int
    let newRecovered, totalRecovered: Int

    enum CodingKeys: String, CodingKey {
        case newConfirmed = "NewConfirmed"
        case totalConfirmed = "TotalConfirmed"
        case newDeaths = "NewDeaths"
        case totalDeaths = "TotalDeaths"
        case newRecovered = "NewRecovered"
        case totalRecovered = "TotalRecovered"
    }
}
