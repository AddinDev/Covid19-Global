//
//  Networking.swift
//  Covid19
//
//  Created by addjn on 29/07/20.
//  Copyright © 2020 pstw._. All rights reserved.
//

import UIKit
import Alamofire

class Networking: ObservableObject {
        
    @Published var dataGlobal = Global.self
    @Published var dataNegara = [Country]()
    
    func getData() {
        AF.request("https://api.covid19api.com/summary")
        .validate()
            .responseDecodable(of: PurpleData.self) { (response) in
            guard let dataCovid = response.value else { return }
//                self.dataGlobal = dataCovid.global
                self.dataNegara = dataCovid.countries
                
        }
    }
}
