//
//  ListCountry.swift
//  Covid19
//
//  Created by addjn on 29/07/20.
//  Copyright © 2020 pstw._. All rights reserved.
//

import SwiftUI
import URLImage

struct ListCountry: View {
    var country: Country
    var body: some View {
        VStack {
            HStack {
                URLImage(URL(string: "https://www.countryflags.io/\(country.countryCode)/flat/64.png")!) { proxy in
                    proxy.image
                        .resizable()
                }
                .frame(width: 40, height: 35)
                .shadow(radius: 5)
                
                Text(country.country)
                    .font(.headline)
                Spacer()
            }
            HStack {
                Text(decimalize(number: Int(country.totalConfirmed))).foregroundColor(.blue)
                Spacer()
                Text(decimalize(number: Int(country.totalDeaths))).foregroundColor(.red)
                Spacer()
                Text(decimalize(number: Int(country.totalRecovered))).foregroundColor(.green)
            }
        }
        .padding()
    }
    
    func decimalize(number: Int) -> String! {
        let numberFormatter = NumberFormatter()
        numberFormatter.numberStyle = NumberFormatter.Style.decimal
        numberFormatter.groupingSeparator = "."
        let formattedNumber = numberFormatter.string(from: NSNumber(value: number))
        return formattedNumber
    }
    
}

//struct ListCountry_Previews: PreviewProvider {
//    static var previews: some View {
//        ListCountry()
//    }
//}
