//
//  ContentView.swift
//  Covid19
//
//  Created by addjn on 27/07/20.
//  Copyright © 2020 pstw._. All rights reserved.
//

import SwiftUI
import SwiftUIRefresh

struct ContentView: View {
    
    @ObservedObject var networking = Networking()
    @State private var keyWord = ""
    @State private var isEditing = false
    @State private var isShowing = false

    var body: some View {
        NavigationView {
            VStack {
//                HStack {
//                    TextField("City / Country", text: $keyWord)
//                        .padding(7)
//                        .background(Color(.systemGray6))
//                        .cornerRadius(8)
//
//                    Button("Search") {
//                        print("your city is dead")
//                    }
//                }
//                .padding(.horizontal, 15)
//                .padding(.vertical, 10)
//
                HStack {
                    Text("Confirmed").foregroundColor(.blue)
                    Spacer()
                    Text("Death").foregroundColor(.red)
                    Spacer()
                    Text("Recovered").foregroundColor(.green)
                }
                .padding(.horizontal, 20)
                .padding(.top, 20)
                
                List(networking.dataNegara) { negara in
                    ListCountry(country: negara)
                }
                .pullToRefresh(isShowing: $isShowing) {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                        self.networking.getData()
                        self.isShowing = false
                        
                    }
                }
                
                Spacer()
                
            }
            .navigationBarTitle("Covid19", displayMode: .inline)
         
                .onAppear{
                    self.networking.getData()
            }
        }
    }
}


//struct ContentView_Previews: PreviewProvider {
//    static var previews: some View {
//        ContentView()
//    }
//}
